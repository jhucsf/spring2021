This file should contain the names of the team members, and
should briefly summarize each team member's contributions to the
code.
